#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
 *   Usage:  lr_simple  word_x word_y N fx fy fxy
 *
 *     Reports likelihood ratio statistic for word_x and word_y
 *     on stdout.  Functions lr_2by2 and log_l adapted
 *     from code written by Ted Dunning.
 *
 *     To compile:   
 *
 *       cc -o lr_simple lr_simple.c -lm
 *
 *     Author:  Philip Resnik
 *
 */

#define EPSILON    3.0e-7

double lr_2by2(double **table, int rows, int cols);
double log_l(double *p, double total, double *k, int cols, double m);

char *word1, *word2;		/* for debugging */

int main(int argc, char **argv)
{
  double N, fx, fy, fxy, lr_value;
  double *contingency_table[2];

  if (argc != 7) 
  {
    fprintf(stderr, "Usage:  %s  word_x word_y N fx fy fxy\n", argv[0]);
    exit(1);
  }

  contingency_table[0] = (double *) calloc(2, sizeof(double));
  contingency_table[1] = (double *) calloc(2, sizeof(double));

  word1 = argv[1];
  word2 = argv[2];
  N     = strtod(argv[3], NULL);
  fx    = strtod(argv[4], NULL);
  fy    = strtod(argv[5], NULL);
  fxy   = strtod(argv[6], NULL);

  contingency_table[0][0] = fxy;
  contingency_table[0][1] = fy - fxy;
  contingency_table[1][0] = fx - fxy;
  contingency_table[1][1] = N - fx - fy + fxy;

  lr_value = lr_2by2(contingency_table, 2, 2);

  fprintf(stdout, "%10lf\n", lr_value);
}

double lr_2by2(double **table, int rows, int cols)	
{
    double sum;
    double rowsums[2], colsums[2];
    double total;
    int i,j;

    if (rows != 2 || cols != 2)
    {
      fprintf(stderr, "lr_2by2: (%s,%s) rows and cols must both equal 2.\n",
	      word1, word2);
      exit(1);
    }

    total = 0;
    for (j=0;j<cols;j++) {
	colsums[j] = 0;
    }

    for (i=0;i<rows;i++) {
	rowsums[i] = 0;
	for (j=0;j<cols;j++) {
	    rowsums[i] += table[i][j];
	    colsums[j] += table[i][j];
	}
	total += rowsums[i];
    }

    sum = 0;
    for (i=0;i<rows;i++) {
	sum +=
	    log_l(table[i], rowsums[i], table[i], cols, rows*cols) -
	    log_l(colsums, total, table[i], cols, rows*cols);
    }
    return 2*sum;
}

double log_l(double *p, double total, double *k, int cols, double m) 
{ 
    int j;
    double sum, logtotal;

    sum = 0;
    logtotal = log((double) total);

    for (j=0;j<cols;j++) {
	if (p[j] > 0) {
	    sum += k[j] * log((double) p[j] / total);
	}
	else if (k[j] > 0) {
	    fprintf(stderr,
		    "(%s,%s) data error, column %d is completely zero\n", 
		    word1, word2, j);
	    exit(1);
	}
    }
    return sum;
}

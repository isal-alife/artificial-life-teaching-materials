#!/bin/sh -- # This comment tells perl not to loop!
eval 'exec /usr/imports/bin/perl -S $0 ${1+"$@"}'
    if 0;

#  Usage: lr_filter N < file.mi
#
#  Has the effect of 
#
#    nawk '{print $5, $6, N, $2, $3, $4}' 
#
#  Format: $5 and $6 are strings, the rest integers, as
#  in file.mi.


$argc = @ARGV;
die ("Usage: lr_filter N\n") if ($argc != 1);
$N = $ARGV[0];

$counter = 0;
while (<STDIN>)
{
    @list = split /\s+/;
    printf("%10s %10s %10d %10d %10d %10d\n", 
	   $list[5], $list[6], $N, $list[2], $list[3], $list[4]);

    ++$counter;
    print STDERR "[$counter]" if ($counter % 100  == 0);
    print STDERR "\n"         if ($counter % 1000 == 0);
}
print STDERR " Done.\n";


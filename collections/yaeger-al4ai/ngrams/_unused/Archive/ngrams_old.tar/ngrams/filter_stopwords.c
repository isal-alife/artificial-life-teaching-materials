#include <stdio.h>
#include <string.h>

#define MAXSTOPWORDS  1000
#define MAXLEN 255

/*
 *  Filtering stoplist words from output of Stats (file.lr)
 */

int main(int argc, char **argv)
{
    FILE *stream;
    char stopwords[MAXSTOPWORDS][MAXLEN];
    char buff[MAXLEN], word1[MAXLEN], word2[MAXLEN];
    int i, numstopwords = 0;
    int found;

    if (argc != 2) {
	fprintf(stderr,  "Usage: %s stopwordfile < file.lr\n", argv[0]);
	exit(1);
    }

    /* Read stopword list */
    if (!(stream = fopen(argv[1], "r"))) {
	fprintf(stderr, "Unable to open %s\n", argv[1]);
	exit(1);
    }
    while (fscanf(stream, " %s", stopwords[numstopwords]) != EOF) 
	++numstopwords; 
    fprintf(stderr, "Read %d stopwords\n", numstopwords);
    fclose(stream);

    /* Filter */
    while (fgets(buff, MAXLEN-1, stdin)) 
    {
	sscanf(buff," %*s %*s %*s %*s %*s %s %s", word1, word2);

	for (found = 0, i = 0; !found && i < numstopwords; i++) {
	    if (!strcasecmp(stopwords[i], word1) 
		|| !strcasecmp(stopwords[i], word2)) 
	    {
		found = 1;
	    }
	}

	if (!found)
 	    printf("%s", buff);
    }
}
